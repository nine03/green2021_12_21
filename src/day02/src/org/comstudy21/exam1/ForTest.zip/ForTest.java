package org.comstudy21.exam1;

public class ForTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum = 0;
		for(int i = 0; i < 100; i += 2) {
			sum = sum + i;
		}
		System.out.println(sum);
	}

}
