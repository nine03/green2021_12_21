package org.comstudy21.exam1;

public class WhileTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum = 0, i = 0;
		while(i < 100) {
			System.out.println(sum);
		}
	}

}
